def is_leap(year):
    leap = False

    if (year % 4 == 0) and (year % 100 != 0):
        leap = True
    elif (year % 100 == 0) and (year % 400 != 0):
        leap = False
    elif (year % 400 == 0):
        leap = True
    else:
        leap = False
    return leap

year = int(input())

if is_leap(year) == False:
    print(year, "- not a leap year")
else:
    print(year, "- leap year")