nums=[]
num_nums=int(input())

for i in range(num_nums):
    val=float(input())
    nums.append(val)

max=max(nums)

for i in range(num_nums):
    print(f'{(nums[i]/max):.2f}')